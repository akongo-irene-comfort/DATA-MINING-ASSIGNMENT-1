# DSC8307 – Data Mining, Modeling and Analytics

## Advent 2026 Semester Assignment

This repository contains my two projects for the DSC8307 assignment. I have kept the code straightforward and divided the analysis into small, clearly explained Jupyter notebook cells. Each notebook follows the questions in the assignment and includes data exploration, preparation, model evaluation and my interpretation of the findings.

## Project files

| File | Purpose |
| --- | --- |
| `Project_1_Bank_Marketing.ipynb` | Project 1: predicting term-deposit subscriptions |
| `Project_2_Concrete_Strength.ipynb` | Project 2: predicting concrete compressive strength |
| `bank-additional-full.csv` | Bank Marketing data |
| `Concrete_Data.csv` | Concrete strength data |
| `bank-additional-full-README.txt` | Bank dataset description and variable definitions |
| `Concrete_Data_README.txt` | Concrete dataset description and units |
| `requirements.txt` | Python packages needed to run the notebooks |

## How I run the projects

1. Download or clone this repository to my computer.
2. Open a terminal in the repository folder.
3. Install the packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Start Jupyter Notebook:

   ```bash
   jupyter notebook
   ```

5. Open **Project_1_Bank_Marketing.ipynb** and select **Kernel → Restart Kernel and Run All Cells** (or **Run → Run All Cells**, depending on the Jupyter version).
6. Repeat for **Project_2_Concrete_Strength.ipynb**.

**Important:** I keep the two CSV files in the same folder as the notebooks because the code reads them by their filenames. No file paths need to be changed when running the notebooks from this folder.

## What I did in each project

### Project 1 – Bank Marketing

I explored the customer data and checked missing and unknown values, duplicate rows and class balance. I prepared the variables without using `duration`, which would not be known before a marketing call. I established a majority-class baseline, compared three classification approaches using cross-validation and evaluated the selected model. I then examined different decision thresholds to explain the balance between unnecessary calls and missed subscribers.

### Project 2 – Concrete Compressive Strength

I examined the mixture ingredients, curing age and compressive strength, and checked data quality. I established a mean-prediction baseline and compared linear and nonlinear regression methods. I inspected prediction errors, residual plots and cases where the model performed less well. I also explained why an observed predictive relationship does not establish what would happen if the mixture were changed in practice.

## Reproducibility and interpretation

- I use a fixed random state where appropriate so that data splits and results are reproducible.
- I fit preprocessing steps through modeling pipelines to avoid learning preprocessing values from test data.
- I use training-data cross-validation for model comparisons and keep test data for final evaluation.
- I explain the limitations of the data and avoid presenting model associations as causal effects.
- My notebooks contain the figures and results alongside the code that produces them.

## Submission

The assignment requires a **public GitHub repository URL** to be submitted through Moodle. After uploading these files to a public GitHub repository, I will copy the repository URL and submit that link to Moodle. A ZIP file or a link to a single notebook is not the required final submission.

## Data sources

The datasets and their accompanying README descriptions were supplied for the DSC8307 Advent 2026 semester assignment.
